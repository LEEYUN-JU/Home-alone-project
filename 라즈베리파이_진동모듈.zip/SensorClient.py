# file: rfcomm-client.py
# auth: Albert Huang <albert@csail.mit.edu>
# desc: simple demonstration of a client application that uses RFCOMM sockets
#       intended for use with rfcomm-server
#
# $Id: rfcomm-client.py 424 2006-08-24 03:35:54Z albert $

from bluetooth import *
import sys
import threading
import time

state =""

def GetState():
    global state
    return state
    
def ConvertState(argv):
    global state
    print("state : " + state) 
    state = argv
     
def receive(sock):
    try:   
        while True:
            recvData = sock.recv(1024)
            if recvData.find('f') == 0:
                ConvertState("FIRE")
                print("other : " + recvData)
            elif recvData.find('g') == 0:
                ConvertState("GAS")
                print("other : " + recvData)
            elif recvData.find('e') == 0:
                ConvertState("")
                print("other : " + recvData)
    except:
        CommuAndroid()
        
def CommuAndroid():
    while True:
        
        if sys.version < '3':
            input = raw_input

        addr = None

        if len(sys.argv) < 2:
            print("no device specified.  Searching all nearby bluetooth devices for")
            print("the SampleServer service")
        else:
            addr = sys.argv[1]
            print("Searching for SampleServer on %s" % addr)

        # search for the SampleServer service
        uuid = "00001101-0000-1000-8000-00805f9b34fb"
        service_matches = find_service( uuid = uuid, address = addr )

        if len(service_matches) == 0:
            print("couldn't find the SampleServer service =(")
            continue
        else:
            break

    first_match = service_matches[0]
    port = first_match["port"]
    name = first_match["name"]
    host = first_match["host"]

    print("connecting to \"%s\" on %s" % (name, host))

    # Create the client socket
    sock=BluetoothSocket( RFCOMM )
    sock.connect((host, port))

    print("connected. GOOD!!!")

    receiver = threading.Thread(target=receive, args=(sock,))

    receiver.start()
                  
    while True:
       time.sleep(1)
       pass

    sock.close()

