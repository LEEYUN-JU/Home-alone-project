import RPi.GPIO as GPIO
import time

def SetBuzer():
    GPIO.setmode(GPIO.BCM)
    BUZ = 17
    GPIO.setup(BUZ,GPIO.OUT)
    return BUZ
def BuzerOff():
    BUZ = SetBuzer()
    GPIO.output(BUZ,GPIO.LOW)
    
def Buzer():
    BUZ = SetBuzer()
    i = 100000
    
    try:
        while i >= 0:
            GPIO.output(BUZ,GPIO.HIGH)
            i = i - 1
        GPIO.output(BUZ,GPIO.LOW)
            
    finally:
        GPIO.cleanup()
            

