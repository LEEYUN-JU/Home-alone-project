import SensorClient as sc
import Sensor as se

se.StartSensor()
sc.CommuAndroid()


