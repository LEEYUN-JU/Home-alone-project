import SensorClient as sc
import Buzer as bz
import threading
import time


def DetectSensor():
    try:
        while True:
            if sc.GetState() != "":
                print("state == " + sc.GetState())
                bz.Buzer()
            
    finally:
        print("not anymore...")

def StartSensor():
    detector = threading.Thread(target=DetectSensor)
    detector.start()

