from bluetooth import *
import sys
import threading
import time

value = ""
connstate = False

def checkconnstate():
    global connstate
    return connstate

def givevalue(getvalue):
    try:
        global value
        value = getvalue
    except Exception as ex:
        print("sc", ex)
        
def send(sock):
    try:
        global value
        while True:
            sendData = value
            sock.send(sendData+"\r\n")
    except Exception as ex:
        connstate = False
        print("sc", ex)
        
def receive(sock):
    try:
        while True:
            recvData = sock.recv(1024)
            if recvData.find('e') == 0:
               print("Situation END")
    except:
        connstate = False
        CommuAndroid()
        
def CommuAndroid():
    global connstate
    try:
        while True:
            connstate = False
            if sys.version < '3':
                input = raw_input

            addr = None

            if len(sys.argv) < 2:
                print("no device specified.  Searching all nearby bluetooth devices for")
                print("the SampleServer service")
            else:
                addr = sys.argv[1]
                print("Searching for SampleServer on %s" % addr)

            uuid = "00001101-0000-1000-8000-00805f9b34fb"
            service_matches = find_service( uuid = uuid, address = addr )

            if len(service_matches) == 0:
                print("couldn't find the SampleServer service =(")
                continue
            else:
                break

        first_match = service_matches[0]
        port = first_match["port"]
        name = first_match["name"]
        host = first_match["host"]

        print("connecting to \"%s\" on %s" % (name, host))

        sock=BluetoothSocket( RFCOMM )
        sock.connect((host, port))

        print("connected. GOOD!!!")
        connstate = True
        
        sender = threading.Thread(target=send, args=(sock,))
        receiver = threading.Thread(target=receive, args=(sock,))

        sender.start()
        receiver.start()
                      
        while True:
           time.sleep(1)
           pass

        sock.close()
        connstate = False
    except Exception as ex:
        print("sc", ex)



