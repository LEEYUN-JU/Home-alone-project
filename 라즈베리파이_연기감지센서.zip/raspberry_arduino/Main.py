import SensorClient as sc
import Sensor as se
import sys
import threading

try:
    se.StartSensor()
    sc.CommuAndroid()
except Exception as ex:
    print("mi", ex)
