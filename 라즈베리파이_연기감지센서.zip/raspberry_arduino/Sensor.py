import SensorClient as sc
import serial
import threading
import sys

def DetectSensor(ser):
    try:
        while True:
            if sc.checkconnstate() == True:
                content = ser.readline()
                contents = content.split('#')
                print(contents[0])
                sc.givevalue(contents[0])
            else:
                continue
            
            
    except Exception as ex:
        print("se", ex)

def StartSensor():
    try:
        ser = serial.Serial("/dev/ttyACM0",9600)
        detector = threading.Thread(target=DetectSensor, args=(ser,))
        detector.start()
    except Exception as ex:
        print("se", ex)

