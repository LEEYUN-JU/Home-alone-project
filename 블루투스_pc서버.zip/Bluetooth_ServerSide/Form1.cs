﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;
using InTheHand.Net.Sockets;
using InTheHand.Net.Bluetooth;
using InTheHand.Windows.Forms;
using InTheHand.Net.Bluetooth.AttributeIds;
using System.IO;

namespace Bluetooth_ServerSide {
    public partial class Form1 : Form {
        Brain brain = Brain.Instance();
        // Threads
        Thread AcceptAndListeningThread;
        // helper variable
        Boolean isConnected = false;
        
        //bluetooth stuff
        BluetoothClient btClient;  //represent the bluetooth client connection
        BluetoothListener btListener; //represent this server bluetooth device

        //wbDB
        private WbDB wbdb = new WbDB();
        List<String> temp = new List<String>();

        public Form1() {  
            InitializeComponent();

            wbdb.Open();

            brain.start();

            if (BluetoothRadio.IsSupported) {

                UpdateLogText("Bluetooth Supported!");
                UpdateLogText("—————————————————————————————————–");
                
                UpdateLogText("Primary Bluetooth Radio Name : " + BluetoothRadio.PrimaryRadio.Name);
                UpdateLogText("Primary Bluetooth Radio Address : " + BluetoothRadio.PrimaryRadio.LocalAddress);

                UpdateLogText("—————————————————————————————————–");

                
                //스레드 시작
                AcceptAndListeningThread = new Thread(AcceptAndListen);
                AcceptAndListeningThread.Start();

                
            }
            else {
                UpdateLogText("Bluetooth not Supported!");
            }
        }

        private delegate void UpdateLogCallback(string strMessage);

   
        public void AcceptAndListen() {
            while (true) {
                if (isConnected) {

                    try {
                        NetworkStream stream = btClient.GetStream();

                        Byte[] bytes = new Byte[512];

                        String retrievedMsg = "";

                        stream.Read(bytes, 0, 512);

                        stream.Flush();

                        for (int i = 0; i < bytes.Length; i++){
                            retrievedMsg += Convert.ToChar(bytes[i]);
                        }

                        //평균값 전송
                        Values value = brain.GetValue();
                        double avg= value.average;
                        string tempstr = Convert.ToString((int)value.average) + "#" +
                                         Convert.ToString((int)value.warnningValue) + "#" +
                                         Convert.ToString((int)value.errorRange);

                        if (avg > 0) {
                            wbdb.InputData(Convert.ToInt32(avg));
                            UpdateLogTextFromThread("SendComplete!!");
                            sendMessage(tempstr);
                            brain.SetAvg(0);
                        }
                        int temp = Convert.ToInt32(retrievedMsg);

                        brain.InputData(temp);

                        UpdateLogTextFromThread(btClient.RemoteMachineName + " : " + retrievedMsg);
                        UpdateLogTextFromThread("");

                    } catch (Exception ex) {
                        isConnected = btClient.Connected;
                        continue;
                    }
                }
                else {

                    try {
                        btListener = new BluetoothListener(BluetoothService.SerialPort);
                        
                        UpdateLogTextFromThread("Starting Listener….");
                        btListener.Start();
                        UpdateLogTextFromThread("Listener Started!");
                        UpdateLogTextFromThread("Accepting incoming connection….");
                        btClient = btListener.AcceptBluetoothClient();
                        isConnected = btClient.Connected;
                        UpdateLogTextFromThread("A Bluetooth Device Connected!");
                    }
                    catch (Exception e) {
                        UpdateLogTextFromThread("There is an error while accepting connection");
                        UpdateLogTextFromThread(e.Message);
                        UpdateLogTextFromThread("Retrying….");
                    }
                }
            }
        }

        
        delegate void UpdateLogTextFromThreadDelegate(String msg);
        public void UpdateLogTextFromThread(String msg) {
            if (!this.IsDisposed && logsText.InvokeRequired)  {
                logsText.Invoke(new UpdateLogTextFromThreadDelegate(UpdateLogText), new Object[]{msg});
            }
        }
      
        public void UpdateLogText(String msg) {
            logsText.Text += msg + Environment.NewLine;
            logsText.SelectionStart = logsText.Text.Length;
            logsText.ScrollToCaret();
        }

        public Boolean sendMessage(string msg) {
                if (!msg.Equals("")) {
                    UTF8Encoding encoder = new UTF8Encoding();
                    NetworkStream stream = btClient.GetStream();
                    stream.Write(encoder.GetBytes(msg + "\r\n"), 0, encoder.GetBytes(msg).Length + 2);
                    stream.Flush();
                }
            return true;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e) {
            try {
                AcceptAndListeningThread.Abort();
                btClient.GetStream().Close();
                btClient.Dispose();
                btListener.Stop();
                FormClosed += new FormClosedEventHandler(Form1_FormClosed);
            }
            catch (Exception){
            }
        }

        void Form1_FormClosed(object sender, FormClosedEventArgs e) {
            wbdb.Close();
            Close();
        }
     
    }
}


