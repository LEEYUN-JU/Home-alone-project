﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Bluetooth_ServerSide {
    struct Values {
        public double average;
        public double errorRange;
        public double warnningValue;
    }
    class Brain {
        #region 싱글톤
        private static Brain instance = null;
        public static Brain Instance() {
            if (instance == null)
                instance = new Brain();

            return instance;
        }
        #endregion
        
        private double Average { get; set; }
        private Queue<int> _storage = new Queue<int>();
        private Random _rand = new Random();
        private const int MaxSize = 1000;
        private bool isStorageFull = false;
        private int higestValue = 0, lowestValue = 9999;
        private Values values = new Values();

        public void InputData(int data) {
            if (_storage.Count >= MaxSize) {
                isStorageFull = true;
                return;
            }
            //최대, 최솟값 저장
            GetValue(data);
            //허용한 큐의 갯수만큼 저장
            _storage.Enqueue(data);
            Console.WriteLine("SaveData" + _storage.Count);
        }

        private void GetValue(int data) {
            if (data > higestValue)
                higestValue = data;

            if (data < lowestValue)
                lowestValue = data;
        }

        public void start() {  
            //계산 및 송신 스레드
            Thread calcThread = new Thread(new ThreadStart(CalcData));
            calcThread.Start();
        }
        public void SetAvg(double result) {
            values.average = result;
        }
        public void SetValue(Values value) {
            values = value;
        }
        public Values GetValue() {
            return values;
        }
        public void CalcData() {
            while (true) {
                if (isStorageFull) {
                   
                    Values values = new Values();
                    //오차범위 계산
                    values.errorRange = higestValue - lowestValue + 50; 
                    //평균계산   
                    values.average = CalcAvg(_storage);
                    //경고범위계산
                    values.warnningValue = values.average + values.errorRange * 2;
                    
                    SetValue(values);
                    Console.WriteLine("Average = " + values.average);
                    SetAvg(values.average);
                  
                    isStorageFull = false;
                }
            }
        }
        private double CalcAvg(Queue<int> queue) {
            int size = queue.Count;
            
            double sum = 0, avg = 0;
            for (int i = 0; i < size; i++) {
                sum += queue.Dequeue();
            }
            avg = sum / size;
            return avg;
        }
    }
}
