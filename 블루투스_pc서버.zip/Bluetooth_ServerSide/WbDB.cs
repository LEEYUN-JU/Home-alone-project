﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Bluetooth_ServerSide {
    public class WbDB {
        SqlConnection conn = new SqlConnection();

        public void Open() {
            if (conn.State == ConnectionState.Open)
                throw new Exception("이미 연결되어있습니다.");
            conn = new SqlConnection();
            //conn.ConnectionString = @"Server=DESKTOP-1M1RAJQ\SQLEXPRESS;database = Hackaton;uid = YUNJU;pwd = 1234;";
            conn.ConnectionString = @"Server=192.168.1.140;database = Hackaton;uid = YUNJU;pwd = 1234;";
            conn.Open(); //데이터 베이스 연결/
        }

        public void Close() {
            if (conn.State == ConnectionState.Open) {
                conn.Close();
                //conn = null;
            } else
                MessageBox.Show("연결 해제 실패");
        }


        public List<String> GetData(List<String> temp) {
            if (conn.State == ConnectionState.Closed)
                throw new Exception("DB 미연결 상태");

            string comtext = "select * from Data where (Date BETWEEN DATEADD(mi, -10, GETDATE()) AND GETDATE())";

            SqlCommand command = new SqlCommand(comtext, conn);

            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read()) {

                temp.Add(reader["Date"].ToString());

                int Average = int.Parse(reader["Average"].ToString());
                temp.Add(Average.ToString());
            }

            reader.Close();
            return temp;
        }

        public void InputData(int size) {
            if (conn.State == ConnectionState.Closed)
                throw new Exception("DB 미연결 상태");

            string comtext = "insert into Data values (GETDATE(), @Average)";
            SqlCommand command = new SqlCommand(comtext, conn);
            //===========================================================
            SqlParameter param_gname = new SqlParameter("@Average", size);
            command.Parameters.Add(param_gname);
            //===========================================================

            if (command.ExecuteNonQuery() != 1)
                throw new Exception("추가 실패");
        }
    }

}
